<footer>

<p>
	<span style="color: #578ebe;
    float: left;
    margin: 13px;">&copy; <?= date('Y'); ?> News CMS</span>
	
</p>

</footer>
</body>

<!-- start: JavaScript-->

<script src="<?= base_url(); ?>public/back/js/jquery-1.9.1.min.js"></script>
<script src="<?= base_url(); ?>public/back/js/jquery-migrate-1.0.0.min.js"></script>

<script src="<?= base_url(); ?>public/back/js/jquery-ui-1.10.0.custom.min.js"></script>

<script src="<?= base_url(); ?>public/back/js/jquery.ui.touch-punch.js"></script>

<script src="<?= base_url(); ?>public/back/js/modernizr.js"></script>

<script src="<?= base_url(); ?>public/back/js/bootstrap.min.js"></script>

<script src="<?= base_url(); ?>public/back/js/jquery.cookie.js"></script>

<script src='<?= base_url(); ?>public/back/js/fullcalendar.min.js'></script>

<script src='<?= base_url(); ?>public/back/js/jquery.dataTables.min.js'></script>

<script src="<?= base_url(); ?>public/back/js/excanvas.js"></script>
<script src="<?= base_url(); ?>public/back/js/jquery.flot.js"></script>
<script src="<?= base_url(); ?>public/back/js/jquery.flot.pie.js"></script>
<script src="<?= base_url(); ?>public/back/js/jquery.flot.stack.js"></script>
<script src="<?= base_url(); ?>public/back/js/jquery.flot.resize.min.js"></script>

<script src="<?= base_url(); ?>public/back/js/jquery.chosen.min.js"></script>

<script src="<?= base_url(); ?>public/back/js/jquery.uniform.min.js"></script>

<script src="<?= base_url(); ?>public/back/js/jquery.cleditor.min.js"></script>

<script src="<?= base_url(); ?>public/back/js/jquery.noty.js"></script>

<script src="<?= base_url(); ?>public/back/js/jquery.elfinder.min.js"></script>

<script src="<?= base_url(); ?>public/back/js/jquery.raty.min.js"></script>

<script src="<?= base_url(); ?>public/back/js/jquery.iphone.toggle.js"></script>

<script src="<?= base_url(); ?>public/back/js/jquery.uploadify-3.1.min.js"></script>

<script src="<?= base_url(); ?>public/back/js/jquery.gritter.min.js"></script>

<script src="<?= base_url(); ?>public/back/js/jquery.imagesloaded.js"></script>

<script src="<?= base_url(); ?>public/back/js/jquery.masonry.min.js"></script>

<script src="<?= base_url(); ?>public/back/js/jquery.knob.modified.js"></script>

<script src="<?= base_url(); ?>public/back/js/jquery.sparkline.min.js"></script>

<script src="<?= base_url(); ?>public/back/js/counter.js"></script>

<script src="<?= base_url(); ?>public/back/js/retina.js"></script>

<script src="<?= base_url(); ?>public/back/js/custom.js"></script>
<!-- end: JavaScript-->

</body>
</html>